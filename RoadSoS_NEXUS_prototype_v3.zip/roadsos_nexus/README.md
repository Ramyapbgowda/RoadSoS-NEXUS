# RoadSoS NEXUS — Working Prototype (v2: Full Command Dashboard)

Team HackNova · HackNova 2026 / IIT Madras submission · Round 2 Prototype Video Pitch

## What this is

A **real, running, end-to-end implementation** of the full NEXUS system — not
just the 5-stage pipeline, but a full command-center dashboard matching the
pitch deck's scope:

- **Live Map** (Leaflet + OpenStreetMap, free, no API key) with hospitals,
  police, hazards, incidents, and an animated ambulance layer
- **AI Pipeline** — incident reporting with photo upload, voice input (browser
  native speech recognition), and full 5-stage pipeline visualization with gauges
- **9-Agent Command Grid** — Triage, Dispatch, Route, Legal, Medical, Prediction,
  Communication, Weather, Traffic — genuinely concurrent, animated live
- **Digital Twin** — canvas-animated road network simulation with a moving
  ambulance, traffic lights, and live ETA, polled from a real backend endpoint
- **Hospitals & Police module** — live bed/ICU/blood-bank availability, nearest
  police station with simulated patrol dispatch
- **Federated Learning simulation** — animated client-node aggregation running
  real FedAvg math
- **Analytics dashboard** — Chart.js visualizations built from real SQLite queries
- **Admin dashboard** — search, filter, CSV export, PDF export, delete

Every stage does genuine computation. Nothing is hardcoded to fake a result.

## What's real vs. what's a stand-in (be upfront about this with judges)

| Pitched Tech | This Prototype | Why |
|---|---|---|
| XGBoost + LSTM risk model | Logistic regression (pure numpy), trained on synthetic data | No xgboost/torch needed to run offline; same input→output contract, swappable |
| YOLOv8 crash severity + object detection | Classical CV heuristic (edge/color analysis) + signal-informed simulated bounding boxes | Real YOLOv8 needs labeled crash-image weights we don't have — this gives a genuine score and plausible detections from a real uploaded photo |
| LangGraph 9-agent orchestration | 9 real Python agent classes run concurrently via ThreadPoolExecutor | Same architecture/behavior; LangGraph wrapping is a documented swap (see agents.py docstring) |
| Whisper + IndicBERT 22-language voice | Browser-native Web Speech API for STT (real, free) + script-based text language detection (7 languages wired) | Full offline 22-language ASR needs a downloaded Whisper model; browser STT is real but needs the user to pre-select a recognition language |
| Twilio/MSG91 SMS + WhatsApp + Call alerts | Alerts logged to `alerts_log.jsonl`, shown in a live notification timeline | No API keys provided; swap is ~3 lines (see notify.py) |
| Flower Federated Learning | Real FedAvg averaging algorithm, animated across simulated device nodes | Same math Flower runs; multi-process/network wiring is the only thing missing |
| SUMO Digital Twin | Canvas-animated simulated road network with real polled backend state | Full SUMO traffic simulation needs the SUMO binary + network files; this matches SUMO's TraCI data contract so it's a clean swap-in point |
| Hospital bed / ICU / blood bank feeds | Deterministic simulated live availability per hospital | No live hospital API exists publicly; seeded directory + simulated churn |

**Be honest about this table if a judge asks.** Say: "The architecture, UI,
and every business decision is real and running — the heaviest pretrained
models are documented swap-in points because we don't have GPU/dataset/API-key
access in the time available." That reads as engineering maturity, not a gap.

## How to run it (from scratch, ~2 minutes)

```bash
cd roadsos_nexus
pip install -r requirements.txt
cd backend
python app.py
```

Then open **http://localhost:5000**. The dashboard needs internet access
only for the map tiles (OpenStreetMap/CARTO) and location search (Nominatim)
— everything else (AI pipeline, agents, analytics, admin) runs fully offline
against the local Flask server and SQLite database.

**Browser tip:** use Chrome or Edge desktop for the voice input feature
(Web Speech API support varies by browser — Firefox/Safari don't support it).

## What to show in your video pitch

1. **Dashboard** — stats, recent incidents, live event log.
2. **Live Map** — zoom around, show hospital/police/hazard layers, search a location.
3. **AI Pipeline** — submit an incident with a photo, night+rain checked, and
   either typed or spoken text. Watch gauges, bounding boxes, and all 5 stages
   populate in real time.
4. **Multi-Agent Grid** — point out all 9 agents completing with real output.
5. **Digital Twin** — show the ambulance animating along the route with live ETA.
6. **Hospitals & Police** — live bed/ICU numbers, nearest patrol unit.
7. **Federated Learning** — run a round, show client nodes lighting up.
8. **Analytics** — real charts built from whatever incidents you've submitted.
9. **Admin** — search/filter, then export CSV and PDF live on screen.
10. **Close on the honesty table above** — this is what separates a serious
    engineering team from a slideware team.

## Project structure

```
roadsos_nexus/
├── requirements.txt
├── README.md
├── backend/
│   ├── app.py            # Flask API — every endpoint the dashboard calls
│   ├── risk_model.py      # Stage 3 — trained risk prediction (numpy logistic regression)
│   ├── cv_severity.py     # Stage 2b — image severity + simulated object detection
│   ├── language.py        # Stage 2a — script-based language detection + responses
│   ├── agents.py          # Stage 4 — 9 concurrent agents
│   ├── hospitals.py        # hospital directory, bed/ICU/blood availability
│   ├── police.py           # police station directory + dispatch simulation
│   ├── hazard_map.py       # crowdsourced hazard reporting + geo-radius queries
│   ├── notify.py           # Stage 5 — simulated SMS/WhatsApp/call alerts + timeline
│   ├── federated.py        # federated averaging (FedAvg) simulation
│   ├── digital_twin.py     # simulated road network + ambulance position
│   ├── analytics.py        # real SQL aggregation for dashboard charts
│   ├── export.py           # CSV + PDF export (no external dependency)
│   └── database.py         # SQLite persistence (offline-capable)
└── frontend/
    ├── index.html          # sidebar-navigated single-page dashboard
    ├── css/style.css       # glassmorphism dark theme, neon accents
    └── js/
        ├── api.js          # backend API client
        ├── map.js          # Leaflet map + all layers
        ├── agents.js       # 9-agent card animation
        ├── charts.js       # Chart.js visualizations + gauges
        ├── digitaltwin.js  # canvas road-network animation
        ├── voice.js        # browser Web Speech API wrapper
        └── app.js          # main controller — navigation + all page wiring
```

## Next steps if you have 48 more hours before the Grand Finale

1. Wire in real `ultralytics` YOLOv8 with a small fine-tuned dataset.
2. Get a free Twilio trial number — real SMS demo beats a JSON log file.
3. Deploy publicly (Render/Railway free tier) so judges get a clickable link.
4. Record the video pitch using this exact dashboard.

